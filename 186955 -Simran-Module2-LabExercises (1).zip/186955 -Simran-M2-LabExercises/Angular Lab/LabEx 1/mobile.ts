export class Mobile{
    mobId:number;
    mobName:string;
    mobCost:number;
    constructor(id,name,cost){
        this.mobId=id;
        this.mobName=name;
        this.mobCost=cost;
    }
    printMobileDetails()
    {   console.log("\n");
        console.log("Mobile ID: "+this.mobId+ 
                    "\nMobile Name: "+this.mobName+
                    "\nMobile Cost: "+this.mobCost);
    }
}